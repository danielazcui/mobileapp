var map;
		  
/*$(document).on('pageinit', '#mapScreen', function(){  
	map = L.map('map'); 				L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
			 
	map.on('locationfound', onLocationFound);
	map.on('locationerror', onLocationError);
			 
	map.locate({setView: true, maxZoom: 16});    
});
		  
function onLocationFound(e) {
	L.marker(e.latlng).addTo(map);
}

function onLocationError(e) {
	alert(e.message);
}*/